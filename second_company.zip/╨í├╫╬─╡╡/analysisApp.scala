package dataAnalysis


import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.SQLContext

object analysisApp {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("createTable")//.setMaster("local")
    val sc = new SparkContext(conf)
    val sqlContext = new SQLContext(sc)
    val hiveContext = new org.apache.spark.sql.hive.HiveContext(sc)
    import sqlContext.implicits._

    /**
      * .getClass.getSimpleName---查看数据类型
      * 插入数据

    hiveContext.sql("use DataBaseName")

    val path=""
    val data = sc.textFile(path).map(x=>x.split("\\s+")).map(x=>(x(0),x(1).toInt,x(2)))
    data.toDF()insertInto("tableName") */

    /**
      * 构建临时表

    val tablePath="hdfs://c3prc-hadoop/user/h_data_platform/platform/miuiads/contest_dataset_app_usage/data/date=01/part-00000"
    val deviceInfoRDD = sc.textFile(tablePath).map(_.split("\t")).map(row => (row(0), row(1)))
    val deviceInfoDataSet = sqlContext.createDataFrame(deviceInfoRDD).toDF("user_id", "use_appList")
    deviceInfoDataSet.registerTempTable("app_usage")
    deviceInfoDataSet.printSchema()

    sqlContext.sql("SELECT * FROM app_usage limit 10").collect().foreach(println)
      */


    val dataPath="hdfs://c3prc-hadoop/user/h_data_platform/platform/miuiads/contest_dataset_app_usage/data/date=*/*"
    var data = sc.textFile(dataPath).map(line=>line.split("\t"))
      .map({line=>
        var useList=line(1).split("|").foreach(line=>{
          line.split(",")
        })
        (line(0),useList)
      }).take(10).foreach(println)

    //.map(f => f.map(f => f.toDouble))

//    val data1 = data.map(f => Vectors.dense(f))





  }

}
